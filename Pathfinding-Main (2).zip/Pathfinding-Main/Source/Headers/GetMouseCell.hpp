#pragma once

gbl::Position<short> get_mouse_cell(const sf::RenderWindow& i_window);